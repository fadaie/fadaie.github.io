
  # دو زبانه رزومه جذاب

  This is a code bundle for دو زبانه رزومه جذاب. The original project is available at https://www.figma.com/design/6V07oPadLeCu4vwIyxYnUV/%D8%AF%D9%88-%D8%B2%D8%A8%D8%A7%D9%86%D9%87-%D8%B1%D8%B2%D9%88%D9%85%D9%87-%D8%AC%D8%B0%D8%A7%D8%A8.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  