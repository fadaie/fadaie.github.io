import { useState } from 'react';
import { motion } from 'motion/react';
import {
  User, Briefcase, GraduationCap, Code, Mail,
  Phone, MapPin, Linkedin, Github, Globe,
  Award, Sparkles, Languages, Heart, Zap
} from 'lucide-react';

interface Language {
  code: 'fa' | 'en';
  name: string;
  direction: 'rtl' | 'ltr';
}

const languages: Language[] = [
  { code: 'fa', name: 'فارسی', direction: 'rtl' },
  { code: 'en', name: 'English', direction: 'ltr' }
];

const content = {
  fa: {
    name: 'نام و نام خانوادگی',
    title: 'توسعه‌دهنده فول‌استک',
    about: 'درباره من',
    aboutText: 'من یک توسعه‌دهنده فول‌استک با بیش از ۵ سال تجربه در ساخت وب‌اپلیکیشن‌های مدرن و کاربرپسند هستم. علاقه‌مند به یادگیری فناوری‌های جدید و حل مسائل پیچیده.',
    experience: 'سوابق کاری',
    education: 'تحصیلات',
    skills: 'مهارت‌ها',
    hardSkills: 'مهارت‌های فنی',
    softSkills: 'مهارت‌های نرم',
    languagesTitle: 'زبان‌ها',
    contact: 'تماس با من',
    experiences: [
      {
        title: 'توسعه‌دهنده ارشد فرانت‌اند',
        company: 'شرکت فناوری پیشرو',
        period: '۱۴۰۱ - اکنون',
        description: 'توسعه و نگهداری اپلیکیشن‌های وب با React و TypeScript'
      },
      {
        title: 'توسعه‌دهنده فول‌استک',
        company: 'استارتاپ نوآور',
        period: '۱۳۹۸ - ۱۴۰۱',
        description: 'طراحی و پیاده‌سازی سیستم‌های بک‌اند و فرانت‌اند'
      }
    ],
    educationList: [
      {
        degree: 'کارشناسی مهندسی کامپیوتر',
        school: 'دانشگاه تهران',
        period: '۱۳۹۴ - ۱۳۹۸',
        gpa: 'معدل: ۱۸.۵'
      }
    ],
    hardSkillsList: [
      { name: 'React & Next.js', level: 95 },
      { name: 'TypeScript', level: 90 },
      { name: 'Node.js', level: 85 },
      { name: 'Python', level: 80 },
      { name: 'MongoDB', level: 85 },
      { name: 'Docker', level: 75 }
    ],
    softSkillsList: [
      'کار تیمی',
      'حل مسئله',
      'مدیریت زمان',
      'ارتباط موثر',
      'خلاقیت',
      'رهبری'
    ],
    languagesList: [
      { name: 'فارسی', level: 'زبان مادری' },
      { name: 'انگلیسی', level: 'پیشرفته' },
      { name: 'عربی', level: 'متوسط' }
    ],
    contactInfo: {
      email: 'example@email.com',
      phone: '+98 912 345 6789',
      location: 'تهران، ایران',
      linkedin: 'linkedin.com/in/username',
      github: 'github.com/username',
      website: 'mywebsite.com'
    }
  },
  en: {
    name: 'Your Full Name',
    title: 'Full Stack Developer',
    about: 'About Me',
    aboutText: 'I am a Full Stack Developer with over 5 years of experience building modern and user-friendly web applications. Passionate about learning new technologies and solving complex problems.',
    experience: 'Work Experience',
    education: 'Education',
    skills: 'Skills',
    hardSkills: 'Technical Skills',
    softSkills: 'Soft Skills',
    languagesTitle: 'Languages',
    contact: 'Contact Me',
    experiences: [
      {
        title: 'Senior Frontend Developer',
        company: 'Leading Tech Company',
        period: '2022 - Present',
        description: 'Developing and maintaining web applications with React and TypeScript'
      },
      {
        title: 'Full Stack Developer',
        company: 'Innovative Startup',
        period: '2019 - 2022',
        description: 'Designing and implementing backend and frontend systems'
      }
    ],
    educationList: [
      {
        degree: 'Bachelor of Computer Engineering',
        school: 'University of Tehran',
        period: '2015 - 2019',
        gpa: 'GPA: 3.8/4.0'
      }
    ],
    hardSkillsList: [
      { name: 'React & Next.js', level: 95 },
      { name: 'TypeScript', level: 90 },
      { name: 'Node.js', level: 85 },
      { name: 'Python', level: 80 },
      { name: 'MongoDB', level: 85 },
      { name: 'Docker', level: 75 }
    ],
    softSkillsList: [
      'Teamwork',
      'Problem Solving',
      'Time Management',
      'Effective Communication',
      'Creativity',
      'Leadership'
    ],
    languagesList: [
      { name: 'Persian', level: 'Native' },
      { name: 'English', level: 'Advanced' },
      { name: 'Arabic', level: 'Intermediate' }
    ],
    contactInfo: {
      email: 'example@email.com',
      phone: '+1 234 567 8900',
      location: 'San Francisco, USA',
      linkedin: 'linkedin.com/in/username',
      github: 'github.com/username',
      website: 'mywebsite.com'
    }
  }
};

export default function Resume() {
  const [currentLang, setCurrentLang] = useState<'fa' | 'en'>('fa');
  const lang = languages.find(l => l.code === currentLang)!;
  const t = content[currentLang];

  return (
    <div
      dir={lang.direction}
      className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 relative overflow-hidden"
      style={{ fontFamily: currentLang === 'fa' ? 'Vazirmatn, sans-serif' : 'Inter, sans-serif' }}
    >
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {/* Glowing Orbs */}
        <motion.div
          className="absolute w-96 h-96 bg-purple-500/20 rounded-full blur-3xl"
          animate={{
            x: [0, 100, 0],
            y: [0, 50, 0],
          }}
          transition={{ duration: 20, repeat: Infinity }}
          style={{ top: '10%', left: '10%' }}
        />
        <motion.div
          className="absolute w-96 h-96 bg-blue-500/20 rounded-full blur-3xl"
          animate={{
            x: [0, -100, 0],
            y: [0, -50, 0],
          }}
          transition={{ duration: 15, repeat: Infinity }}
          style={{ bottom: '10%', right: '10%' }}
        />
        <motion.div
          className="absolute w-72 h-72 bg-pink-500/20 rounded-full blur-3xl"
          animate={{
            x: [0, -80, 0],
            y: [0, 80, 0],
          }}
          transition={{ duration: 18, repeat: Infinity }}
          style={{ top: '50%', right: '20%' }}
        />

        {/* Floating Glass Cards */}
        <motion.div
          className="absolute w-32 h-32 rounded-3xl bg-gradient-to-br from-purple-500/20 to-blue-500/20 backdrop-blur-sm border border-purple-500/30"
          style={{
            top: '15%',
            left: '12%',
            boxShadow: '0 20px 60px rgba(168, 85, 247, 0.3)',
          }}
          animate={{
            y: [0, -20, 0],
            rotate: [-5, 5, -5],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />

        <motion.div
          className="absolute w-24 h-24 rounded-2xl bg-gradient-to-br from-pink-500/20 to-purple-500/20 backdrop-blur-sm border border-pink-500/30"
          style={{
            bottom: '20%',
            left: '8%',
            boxShadow: '0 15px 50px rgba(236, 72, 153, 0.3)',
          }}
          animate={{
            y: [0, 15, 0],
            rotate: [3, -3, 3],
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />

        {/* Hexagons */}
        <motion.div
          className="absolute"
          style={{
            top: '35%',
            right: '15%',
          }}
          animate={{
            y: [0, -25, 0],
            scale: [1, 1.1, 1],
          }}
          transition={{
            duration: 12,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          <div
            className="w-28 h-28 bg-gradient-to-br from-cyan-500/25 to-blue-500/25 backdrop-blur-sm border border-cyan-500/40"
            style={{
              clipPath: 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)',
              boxShadow: '0 0 40px rgba(6, 182, 212, 0.4)',
            }}
          />
        </motion.div>

        <motion.div
          className="absolute"
          style={{
            top: '65%',
            right: '8%',
          }}
          animate={{
            y: [0, 20, 0],
            scale: [1, 0.95, 1],
          }}
          transition={{
            duration: 9,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          <div
            className="w-20 h-20 bg-gradient-to-br from-violet-500/25 to-fuchsia-500/25 backdrop-blur-sm border border-violet-500/40"
            style={{
              clipPath: 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)',
              boxShadow: '0 0 35px rgba(139, 92, 246, 0.4)',
            }}
          />
        </motion.div>

        {/* Diamond Shapes */}
        <motion.div
          className="absolute"
          style={{
            top: '50%',
            left: '75%',
          }}
          animate={{
            y: [0, -18, 0],
            rotate: [0, 10, 0],
          }}
          transition={{
            duration: 11,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          <div
            className="w-24 h-24 bg-gradient-to-br from-amber-500/20 to-orange-500/20 backdrop-blur-sm border border-amber-500/30"
            style={{
              transform: 'rotate(45deg)',
              boxShadow: '0 0 40px rgba(251, 191, 36, 0.3)',
            }}
          />
        </motion.div>

        {/* Floating Spheres with Gradient */}
        <motion.div
          className="absolute w-20 h-20 rounded-full bg-gradient-to-br from-cyan-400/40 to-blue-600/40"
          style={{
            top: '25%',
            right: '25%',
            boxShadow: '0 0 40px rgba(34, 211, 238, 0.6), inset 0 0 20px rgba(255, 255, 255, 0.2)',
          }}
          animate={{
            y: [0, -50, 0],
            x: [0, 30, 0],
            scale: [1, 1.2, 1],
          }}
          transition={{
            duration: 15,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />

        <motion.div
          className="absolute w-16 h-16 rounded-full bg-gradient-to-br from-violet-400/40 to-fuchsia-600/40"
          style={{
            bottom: '35%',
            right: '35%',
            boxShadow: '0 0 35px rgba(167, 139, 250, 0.6), inset 0 0 15px rgba(255, 255, 255, 0.2)',
          }}
          animate={{
            y: [0, 40, 0],
            x: [0, -25, 0],
            scale: [1, 1.15, 1],
          }}
          transition={{
            duration: 12,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />

        {/* Grid Lines */}
        <motion.div
          className="absolute w-full h-full"
          style={{
            backgroundImage: `
              linear-gradient(90deg, rgba(139, 92, 246, 0.1) 1px, transparent 1px),
              linear-gradient(rgba(139, 92, 246, 0.1) 1px, transparent 1px)
            `,
            backgroundSize: '80px 80px',
            transform: 'perspective(500px) rotateX(60deg)',
            transformOrigin: 'center center',
          }}
          animate={{
            opacity: [0.3, 0.5, 0.3],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />

        {/* Particle Dots */}
        {[...Array(15)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-2 h-2 bg-purple-400/60 rounded-full"
            style={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
              boxShadow: '0 0 10px rgba(168, 85, 247, 0.8)',
            }}
            animate={{
              y: [0, -100, 0],
              opacity: [0, 1, 0],
              scale: [0, 1.5, 0],
            }}
            transition={{
              duration: 5 + Math.random() * 5,
              repeat: Infinity,
              delay: Math.random() * 3,
              ease: "easeInOut"
            }}
          />
        ))}
      </div>

      {/* Language Switcher */}
      <div className="fixed top-6 right-6 z-50">
        <motion.div
          className="flex gap-2 bg-white/10 backdrop-blur-lg rounded-full p-1 border border-white/20"
          whileHover={{ scale: 1.05 }}
        >
          {languages.map((language) => (
            <button
              key={language.code}
              onClick={() => setCurrentLang(language.code)}
              className={`px-4 py-2 rounded-full transition-all duration-300 flex items-center gap-2 ${
                currentLang === language.code
                  ? 'bg-gradient-to-r from-purple-500 to-blue-500 text-white shadow-lg'
                  : 'text-white/70 hover:text-white'
              }`}
            >
              <Languages className="w-4 h-4" />
              <span className="font-medium">{language.name}</span>
            </button>
          ))}
        </motion.div>
      </div>

      {/* Main Content */}
      <div className="relative z-10 max-w-6xl mx-auto px-6 py-12">
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <motion.div
            className="w-40 h-40 mx-auto mb-8 rounded-full bg-gradient-to-br from-purple-400 via-pink-500 to-blue-500 p-1 shadow-2xl"
            whileHover={{ scale: 1.1, rotate: 5 }}
            transition={{ type: "spring", stiffness: 300 }}
          >
            <div className="w-full h-full rounded-full bg-slate-800 flex items-center justify-center">
              <User className="w-20 h-20 text-white" />
            </div>
          </motion.div>

          <motion.h1
            className="text-6xl font-bold mb-4 bg-gradient-to-r from-purple-400 via-pink-500 to-blue-500 bg-clip-text text-transparent"
            style={{ fontFamily: currentLang === 'fa' ? 'Vazirmatn, sans-serif' : 'Orbitron, sans-serif' }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            {t.name}
          </motion.h1>

          <motion.p
            className="text-2xl text-white/80 mb-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
          >
            {t.title}
          </motion.p>

          <motion.div
            className="flex justify-center gap-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
          >
            <SocialIcon icon={<Linkedin />} />
            <SocialIcon icon={<Github />} />
            <SocialIcon icon={<Globe />} />
          </motion.div>
        </motion.div>

        {/* About Section */}
        <Section
          icon={<Sparkles />}
          title={t.about}
          delay={0.8}
        >
          <p className="text-white/80 text-lg leading-relaxed">
            {t.aboutText}
          </p>
        </Section>

        {/* Experience Section */}
        <Section
          icon={<Briefcase />}
          title={t.experience}
          delay={1}
        >
          <div className="space-y-6">
            {t.experiences.map((exp, index) => (
              <ExperienceCard key={index} {...exp} delay={1.2 + index * 0.2} />
            ))}
          </div>
        </Section>

        {/* Education Section */}
        <Section
          icon={<GraduationCap />}
          title={t.education}
          delay={1.6}
        >
          <div className="space-y-6">
            {t.educationList.map((edu, index) => (
              <EducationCard key={index} {...edu} delay={1.8 + index * 0.2} />
            ))}
          </div>
        </Section>

        {/* Skills Section */}
        <Section
          icon={<Code />}
          title={t.skills}
          delay={2}
        >
          <div className="space-y-8">
            {/* Hard Skills */}
            <div>
              <h3 className="text-2xl font-bold text-white mb-6 flex items-center gap-3">
                <Zap className="w-6 h-6 text-purple-400" />
                {t.hardSkills}
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {t.hardSkillsList.map((skill, index) => (
                  <SkillBar key={index} {...skill} delay={2.2 + index * 0.1} />
                ))}
              </div>
            </div>

            {/* Soft Skills */}
            <div>
              <h3 className="text-2xl font-bold text-white mb-6 flex items-center gap-3">
                <Heart className="w-6 h-6 text-pink-400" />
                {t.softSkills}
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {t.softSkillsList.map((skill, index) => (
                  <SoftSkillBadge key={index} name={skill} delay={2.2 + index * 0.1} />
                ))}
              </div>
            </div>
          </div>
        </Section>

        {/* Languages Section */}
        <Section
          icon={<Languages />}
          title={t.languagesTitle}
          delay={2.6}
        >
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {t.languagesList.map((lang, index) => (
              <LanguageCard key={index} {...lang} delay={2.8 + index * 0.1} />
            ))}
          </div>
        </Section>

        {/* Contact Section */}
        <Section
          icon={<Mail />}
          title={t.contact}
          delay={3.2}
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <ContactItem icon={<Mail />} text={t.contactInfo.email} delay={3} />
            <ContactItem icon={<Phone />} text={t.contactInfo.phone} delay={3.1} />
            <ContactItem icon={<MapPin />} text={t.contactInfo.location} delay={3.2} />
            <ContactItem icon={<Globe />} text={t.contactInfo.website} delay={3.3} />
          </div>
        </Section>
      </div>
    </div>
  );
}

function Section({
  icon,
  title,
  children,
  delay
}: {
  icon: React.ReactNode;
  title: string;
  children: React.ReactNode;
  delay: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay }}
      className="mb-16"
    >
      <div className="flex items-center gap-4 mb-8">
        <motion.div
          className="w-14 h-14 rounded-2xl bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center shadow-xl"
          whileHover={{ scale: 1.1, rotate: 10 }}
          transition={{ type: "spring", stiffness: 400 }}
        >
          <div className="text-white w-7 h-7">
            {icon}
          </div>
        </motion.div>
        <h2 className="text-4xl font-bold text-white">{title}</h2>
      </div>
      <div className="bg-white/5 backdrop-blur-lg rounded-3xl p-8 border border-white/10 shadow-2xl">
        {children}
      </div>
    </motion.div>
  );
}

function SocialIcon({ icon }: { icon: React.ReactNode }) {
  return (
    <motion.a
      href="#"
      className="w-12 h-12 rounded-full bg-white/10 backdrop-blur-lg border border-white/20 flex items-center justify-center text-white hover:bg-gradient-to-br hover:from-purple-500 hover:to-blue-500 transition-all duration-300"
      whileHover={{ scale: 1.2, rotate: 10 }}
      whileTap={{ scale: 0.9 }}
    >
      {icon}
    </motion.a>
  );
}

function ExperienceCard({
  title,
  company,
  period,
  description,
  delay
}: {
  title: string;
  company: string;
  period: string;
  description: string;
  delay: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
      className="bg-gradient-to-br from-white/5 to-white/10 backdrop-blur-sm p-6 rounded-2xl border border-white/10 hover:border-purple-500/50 transition-all duration-300 group"
      whileHover={{ scale: 1.02 }}
    >
      <div className="flex items-start gap-4">
        <motion.div
          className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center flex-shrink-0"
          whileHover={{ scale: 1.1, rotate: 5 }}
        >
          <Briefcase className="w-6 h-6 text-white" />
        </motion.div>
        <div className="flex-1">
          <h3 className="text-xl font-bold text-white mb-1 group-hover:text-purple-400 transition-colors">{title}</h3>
          <p className="text-purple-400 font-medium mb-2">{company}</p>
          <p className="text-white/60 text-sm mb-3">{period}</p>
          <p className="text-white/80">{description}</p>
        </div>
      </div>
    </motion.div>
  );
}

function EducationCard({
  degree,
  school,
  period,
  gpa,
  delay
}: {
  degree: string;
  school: string;
  period: string;
  gpa: string;
  delay: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
      className="bg-gradient-to-br from-white/5 to-white/10 backdrop-blur-sm p-6 rounded-2xl border border-white/10 hover:border-purple-500/50 transition-all duration-300 group"
      whileHover={{ scale: 1.02 }}
    >
      <div className="flex items-start gap-4">
        <motion.div
          className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center flex-shrink-0"
          whileHover={{ scale: 1.1, rotate: 5 }}
        >
          <Award className="w-6 h-6 text-white" />
        </motion.div>
        <div className="flex-1">
          <h3 className="text-xl font-bold text-white mb-1 group-hover:text-purple-400 transition-colors">{degree}</h3>
          <p className="text-purple-400 font-medium mb-2">{school}</p>
          <p className="text-white/60 text-sm mb-1">{period}</p>
          <p className="text-white/80">{gpa}</p>
        </div>
      </div>
    </motion.div>
  );
}

function SkillBar({
  name,
  level,
  delay
}: {
  name: string;
  level: number;
  delay: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5, delay }}
      className="space-y-2"
    >
      <span className="text-white font-medium">{name}</span>
      <div className="h-2.5 bg-white/10 rounded-full overflow-hidden">
        <motion.div
          className="h-full bg-gradient-to-r from-purple-500 to-blue-500 rounded-full"
          initial={{ width: 0 }}
          animate={{ width: `${level}%` }}
          transition={{ duration: 1, delay: delay + 0.3, ease: "easeOut" }}
        />
      </div>
    </motion.div>
  );
}

function SoftSkillBadge({
  name,
  delay
}: {
  name: string;
  delay: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.4, delay }}
      className="bg-gradient-to-br from-pink-500/20 to-purple-500/20 backdrop-blur-sm px-4 py-3 rounded-xl border border-pink-500/30 text-center hover:scale-105 transition-transform"
      whileHover={{ scale: 1.1 }}
    >
      <span className="text-white font-medium">{name}</span>
    </motion.div>
  );
}

function LanguageCard({
  name,
  level,
  delay
}: {
  name: string;
  level: string;
  delay: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
      className="bg-gradient-to-br from-white/5 to-white/10 backdrop-blur-sm p-6 rounded-2xl border border-white/10 hover:border-purple-500/50 transition-all duration-300 text-center group"
      whileHover={{ scale: 1.05 }}
    >
      <motion.div
        className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center"
        whileHover={{ rotate: 10 }}
      >
        <Globe className="w-8 h-8 text-white" />
      </motion.div>
      <h4 className="text-xl font-bold text-white mb-2 group-hover:text-purple-400 transition-colors">{name}</h4>
      <p className="text-white/70">{level}</p>
    </motion.div>
  );
}

function ContactItem({
  icon,
  text,
  delay
}: {
  icon: React.ReactNode;
  text: string;
  delay: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.4, delay }}
      className="flex items-center gap-4 bg-white/5 p-4 rounded-2xl border border-white/10 hover:bg-white/10 transition-all duration-300 group"
      whileHover={{ scale: 1.05 }}
    >
      <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
        <div className="text-white w-5 h-5">
          {icon}
        </div>
      </div>
      <span className="text-white/80 group-hover:text-white transition-colors">{text}</span>
    </motion.div>
  );
}
