
  # 3D Model Personal Website

  This is a code bundle for 3D Model Personal Website. The original project is available at https://fresco-mouse-29911361.figma.site

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  
